/*
* This is a C99 Formatted file. I was having a lot more trouble finding C docs
* for some of the stuff I wanted to document, so I'll have to come back later
* and add them as I find them.
* This file needs to be cross compiled with the command:
* `clang -target i686-elf -c src/kernel.c -o build/kernel.o -std=gnu99 -ffreestanding -nostdlib -Wall -Wextra`
*/

/*
* Since there is no C Library in the OS we can only use header
* files defined by the compiler.
* I need to investigate harder where I can find documentation on this.
*/
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/*
* Hardware text mode color constants.
* https://en.wikipedia.org/wiki/Video_Graphics_Array#Color_palette
* -----
* CGA	EGA	VGA	RGB	Web	Example
* 0x0	0x0	0,0,0	0,0,0	#000000	black
* 0x1	0x1	0,0,42	0,0,170	#0000aa	blue
* 0x2	0x2	00,42,00	0,170,0	#00aa00	green
* 0x3	0x3	00,42,42	0,170,170	#00aaaa	cyan
* 0x4	0x4	42,00,00	170,0,0	#aa0000	red
* 0x5	0x5	42,00,42	170,0,170	#aa00aa	magenta
* 0x6	0x14	42,21,00	170,85,0	#aa5500	brown
* 0x7	0x7	42,42,42	170,170,170	#aaaaaa	gray
* 0x8	0x38	21,21,21	85,85,85	#555555	dark gray
* 0x9	0x39	21,21,63	85,85,255	#5555ff	bright blue
* 0xA	0x3A	21,63,21	85,255,85	#55ff55	bright green
* 0xB	0x3B	21,63,63	85,255,255	#55ffff	bright cyan
* 0xC	0x3C	63,21,21	255,85,85	#ff5555	bright red
* 0xD	0X3D	63,21,63	255,85,255	#ff55ff	bright  magenta
* 0xE	0x3E	63,63,21	255,255,85	#ffff55	Yellow
* 0xF	0x3F	63,63,63	255,255,255	#ffffff	white
*/
enum vga_color {
	COLOR_BLACK = 0,
	COLOR_BLUE = 1,
	COLOR_GREEN = 2,
	COLOR_CYAN = 3,
	COLOR_RED = 4,
	COLOR_MAGENTA = 5,
	COLOR_BROWN = 6,
	COLOR_LIGHT_GREY = 7,
	COLOR_DARK_GREY = 8,
	COLOR_LIGHT_BLUE = 9,
	COLOR_LIGHT_GREEN = 10,
	COLOR_LIGHT_CYAN = 11,
	COLOR_LIGHT_RED = 12,
	COLOR_LIGHT_MAGENTA = 13,
	COLOR_LIGHT_BROWN = 14,
	COLOR_WHITE = 15,
};

/*
* VGA Text buffer
* https://en.wikipedia.org/wiki/VGA-compatible_text_mode#Text_buffer
* Each screen character is actually represented by two bytes aligned as a
* 16-bit word accessible by the CPU in a single operation.
* The lower, or character, byte is the actual code point for the current
* character set, and the higher, or attribute, byte is a bit field used to
* select various video attributes such as color, blinking, character set, and
* so forth. This byte-pair scheme is among the features that the VGA inherited
* from the EGA, CGA, and ultimately from the MDA.
*/
/*
* This is what the data structure actually looks like.
* ----------------------------------------------------
* |               Attribute               |Character |
* |    7|             654|            3210|  76543210|
* |Blink|Background color|Foreground color|Code point|
* ----------------------------------------------------
* The blink bit is sometimes actually more room for background color.
* I am not in a mode that supports a blink bit, so all four are for background
*/

/*
* This function outputs the higher-half, or foreground color, background color,
* and blink mode of the VGA Text Buffer Datastructure
*/
uint8_t make_color(enum vga_color fg, enum vga_color bg) {
	return fg | bg << 4;
}

/*
* This function creates the lower-half or character/code point of the VGA
* Text Buffer and combines it with an already created higher-half/color.
*/
uint16_t make_vgaentry(char c, uint8_t color) {
	uint16_t c16 = c;
	uint16_t color16 = color;
	return c16 | color16 << 8;
}

size_t strlen(const char* str) {
	size_t ret = 0;
	while ( str[ret] != 0 )
		ret++;
	return ret;
}

/*
* We are going to be in VGA 03h mode which supports only 80x25 Text resolution,
* 16 colors, and 8 pages
*/
static const size_t VGA_WIDTH = 80;
static const size_t VGA_HEIGHT = 25;

/*
* Column and Row are VGA Cursor Positions
* These values are all global so they can be modified from inside functions.
*/
size_t terminal_row;
size_t terminal_column;
uint8_t terminal_color; /* VGA Text Buffer - Higher Half */
uint16_t* terminal_buffer; /* VGA Text Buffer Pointer - could be assigned now */

/*
* non returning function
* sets the starting VGA cursor position to 0,0 ; the upper lefthand corner
*
* https://en.wikipedia.org/wiki/VGA-compatible_text_mode#Access_methods
* The text screen video memory for colour monitors resides at 0xB8000
* initializes the terminal buffer to a pointer 0xB8000
*
* Creates a text buffer color with a cyan foreground and a black background
* Assigns every (16 bit word sized) position in the text screen video memory
* to a ' ' or space character.
*/
void terminal_initialize() {
	terminal_row = 0;
	terminal_column = 0;
	terminal_color = make_color(COLOR_LIGHT_CYAN, COLOR_BLACK);

	terminal_buffer = (uint16_t*) 0xB8000;
	for (size_t y = 0; y < VGA_HEIGHT; y++) {
		for (size_t x = 0; x < VGA_WIDTH; x++) {
			const size_t index = y * VGA_WIDTH + x;
			terminal_buffer[index] = make_vgaentry(' ', terminal_color);
		}
	}
}

/*
* Change the global terminal color to a new color. (created with make_color)
*/
void terminal_setcolor(uint8_t color) {
	terminal_color = color;
}

/*
* Assign a character and the global color, to a specific location in VGA memory.
*/
void terminal_putentryat(char c, uint8_t color, size_t x, size_t y) {
	const size_t index = y * VGA_WIDTH + x;
	terminal_buffer[index] = make_vgaentry(c, color);
}

/*
* Assign a character, and the global color, to the 'cursor' position.
*/
void terminal_putchar(char c) {
	terminal_putentryat(c, terminal_color, terminal_column, terminal_row);
	if (++terminal_column == VGA_WIDTH) {
		terminal_column = 0;
		if (++terminal_row == VGA_HEIGHT) {
			terminal_row = 0;
		}
	}
}

/*
* Assign a series of characters in order to VGA Memory, for outputing strings.
* Does not support newlines...
*/
void terminal_writestring(const char* data) {
	size_t datalen = strlen(data);
	for (size_t i = 0; i < datalen; i++)
		terminal_putchar(data[i]);
}

/*
* Setup the VGA Buffer Memory and Print the String "Hello, kernel!\n"
*/
void kernel_main() {
	terminal_initialize();
	terminal_writestring("Hello, kernel!\n");
}
