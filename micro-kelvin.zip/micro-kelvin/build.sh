#!/usr/bin/env bash

# Build the ASM File which Bootstraps the C Callstack
nasm -f elf -M src/boot.asm -o build/boot.o

# Build the C File which Bootstraps the VGA Color Text mode
# And outputs the text 'Hello Kernel'
clang -target i686-elf -c src/kernel.c -o build/kernel.o -std=gnu99 -ffreestanding -nostdlib -Wall -Wextra

# Link the ELF objects together correctly into a bootable binary.
# TODO: Figure out the -lgcc thing.
clang -T src/linker.ld -o build/micro-kelvin.bin -ffreestanding -O2 -nostdlib build/boot.o build/kernel.o
